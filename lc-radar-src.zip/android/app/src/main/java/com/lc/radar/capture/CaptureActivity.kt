package com.lc.radar.capture

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import com.lc.radar.net.FlowAgg
import com.lc.radar.net.FlowKey
import com.lc.radar.net.NetLog
import com.lc.radar.net.ProtoProbe
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * 抓包显示界面：流列表（按流量排序） + 单包 hex + 业务协议盲扫。
 * 全部数据来自 NetLog，由 CaptureVpnService 在 VPN 层喂进来。
 */
class CaptureActivity : Activity() {

    private lateinit var summary: TextView
    private lateinit var listView: ListView
    private val adapter = FlowAdapter()
    private val h = Handler(Looper.getMainLooper())
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private var showByApp = false
    private var appRows: List<Pair<String, Long>> = emptyList()

    private val tick = object : Runnable {
        override fun run() {
            refresh()
            h.postDelayed(this, 900)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun d(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(12), d(14), d(12), d(4))
        }

        summary = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextColor(0xFF9FE8C8.toInt())
        }
        root.addView(summary, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        bar.addView(mkBtn("按应用") {
            showByApp = !showByApp
            adapter.notifyDataSetChanged()
        })
        bar.addView(mkBtn("清空") {
            NetLog.reset()
            refresh()
        })
        bar.addView(mkBtn("盲扫首个流") { scanFirstFlow() })
        root.addView(bar)

        listView = ListView(this).apply {
            divider = null
            dividerHeight = d(4)
            adapter = this@CaptureActivity.adapter
            setOnItemClickListener { _, _, pos, _ -> onRow(pos) }
            setOnItemLongClickListener { _, _, pos, _ ->
                onRowHex(pos)
                true
            }
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        title = "抓包显示"
    }

    override fun onResume() {
        super.onResume()
        h.post(tick)
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
    }

    private fun mkBtn(label: String, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            textSize = 12f
            isAllCaps = false
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

    // ── 刷新 ──────────────────────────────────────────────────
    private fun refresh() {
        val flows = NetLog.topFlows()
        appRows = NetLog.byApp()
        val up = (System.currentTimeMillis() - NetLog.startedAt).coerceAtLeast(0) / 1000
        summary.text = buildString {
            append("包 ").append(NetLog.totalPackets.get())
            append(" · 字节 ").append(human(NetLog.totalBytes.get()))
            append(" · 流 ").append(flows.size)
            append(" · ").append(up).append("s")
            if (NetLog.note.isNotBlank()) append('\n').append(NetLog.note)
        }
        adapter.flows = flows
        adapter.apps = appRows
        adapter.byApp = showByApp
        adapter.notifyDataSetChanged()
    }

    private fun onRow(pos: Int) {
        if (adapter.byApp) return
        val f = adapter.flows.getOrNull(pos) ?: return
        val sb = StringBuilder()
        sb.append(f.first.short).append('\n')
        sb.append("包 ").append(f.second.packets).append("  字节 ").append(human(f.second.bytes)).append('\n')
        f.second.sni?.let { sb.append("标记 ").append(it).append('\n') }
        f.second.app?.let { sb.append("应用 ").append(it).append(" (uid ").append(f.second.uid).append(")\n") }
        if (f.second.head.isNotBlank()) sb.append("首包 ").append(f.second.head)
        AlertDialog.Builder(this)
            .setTitle("流详情")
            .setMessage(sb.toString())
            .setPositiveButton("关闭", null)
            .show()
    }

    /** 长按：把这个流最近几包的 hex 拉出来 */
    private fun onRowHex(pos: Int) {
        if (adapter.byApp) return
        val f = adapter.flows.getOrNull(pos) ?: return
        val dump = NetLog.packetList().filter { it.key == f.first }.takeLast(12)
        if (dump.isEmpty()) return
        val sb = StringBuilder()
        for (p in dump) sb.append(fmt.format(Date(p.t))).append("  ").append(p.len)
            .append("B  ").append(p.hex).append('\n')
        AlertDialog.Builder(this)
            .setTitle("最近 ${dump.size} 包（前 96B）")
            .setMessage(sb.toString())
            .setPositiveButton("关闭", null)
            .show()
    }

    /** 对第一个流的首包做一次 float 三元组盲扫（判断密文/明文） */
    private fun scanFirstFlow() {
        val f = NetLog.topFlows().firstOrNull() ?: return
        val head = NetLog.packetList().firstOrNull { it.key == f.first } ?: return
        val bytes = hexToBytes(head.hex)
        val report = ProtoProbe.scanReport(ProtoProbe.deobfuscate(bytes, bytes.size))
        AlertDialog.Builder(this)
            .setTitle("协议盲扫")
            .setMessage("流: ${f.first.short}\n\n$report\n\n（提示：密文状态下扫描结果无意义，先补 ProtoProbe.sessionKey）")
            .setPositiveButton("关闭", null)
            .show()
    }

    private fun hexToBytes(s: String): ByteArray {
        val clean = s.replace(" ", "")
        val out = ByteArray(clean.length / 2)
        for (i in out.indices) {
            out[i] = clean.substring(i * 2, i * 2 + 2).toInt(16).toByte()
        }
        return out
    }

    private fun human(v: Long): String = when {
        v > 1024 * 1024 -> String.format(Locale.US, "%.2fMB", v / 1048576.0)
        v > 1024 -> String.format(Locale.US, "%.1fKB", v / 1024.0)
        else -> "${v}B"
    }

    // ── 列表 ──────────────────────────────────────────────────
    private inner class FlowAdapter : BaseAdapter() {
        var flows: List<Pair<FlowKey, FlowAgg>> = emptyList()
        var apps: List<Pair<String, Long>> = emptyList()
        var byApp = false

        override fun getCount(): Int = if (byApp) apps.size else flows.size
        override fun getItem(position: Int): Any? = null
        override fun getItemId(position: Int): Long = position.toLong()

        override fun getView(position: Int, convert: View?, parent: ViewGroup?): View {
            val dp = resources.displayMetrics.density
            val box = (convert as? LinearLayout) ?: LinearLayout(this@CaptureActivity).apply {
                orientation = LinearLayout.VERTICAL
                setPadding((8 * dp).toInt(), (6 * dp).toInt(), (8 * dp).toInt(), (6 * dp).toInt())
                addView(TextView(this@CaptureActivity).apply {
                    typeface = Typeface.MONOSPACE
                    textSize = 11.5f
                    setTextColor(0xFFE6FFF6.toInt())
                })
                addView(TextView(this@CaptureActivity).apply {
                    typeface = Typeface.MONOSPACE
                    textSize = 10f
                    setTextColor(0xFF7FBFAA.toInt())
                })
            }
            val main = box.getChildAt(0) as TextView
            val sub = box.getChildAt(1) as TextView

            if (byApp) {
                val a = apps[position]
                main.text = a.first
                sub.text = human(a.second)
            } else {
                val (k, v) = flows[position]
                main.text = k.short
                sub.text = buildString {
                    append(k.protoName).append("  ").append(v.packets).append("包  ").append(human(v.bytes))
                    v.sni?.let { append("  ").append(it) }
                    v.app?.let { append("  ").append(it) }
                }
            }
            return box
        }
    }
}
