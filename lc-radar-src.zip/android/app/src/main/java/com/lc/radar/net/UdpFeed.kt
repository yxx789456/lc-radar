package com.lc.radar.net

import com.lc.radar.Cfg
import com.lc.radar.core.WorldState
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.SocketTimeoutException

/**
 * 数据源 1：UDP 接收（PC 端视觉/YOLO 把坐标推过来，或第二台手机/外部设备）。
 *
 * 帧格式（UDP 每包一帧，UTF-8，换行可省）：
 *   {"self":{"x":0,"z":0,"yaw":0},"ent":[{"id":1,"x":12,"z":-4,"kind":"enemy"}]}
 * 也支持 `ping` 文本包，只更新心跳。
 */
object UdpFeed {

    @Volatile
    var running = false
        private set

    @Volatile
    var lastPackets: Long = 0
        private set

    @Volatile
    var lastFrom: String = ""
        private set

    private var sock: DatagramSocket? = null
    private var thread: Thread? = null

    fun start(port: Int = Cfg.udpPort): Boolean {
        if (running) return true
        return try {
            val s = DatagramSocket(null)
            s.reuseAddress = true
            val bind = Cfg.udpBind
            val addr = if (bind.isBlank()) InetSocketAddress(port) else InetSocketAddress(bind, port)
            s.bind(addr)
            s.soTimeout = 1000
            sock = s
            running = true
            WorldState.setSource("UDP:$port")
            thread = Thread({ loop(s) }, "lc-udp-feed").also {
                it.isDaemon = true
                it.start()
            }
            true
        } catch (t: Throwable) {
            running = false
            WorldState.setSource("UDP 绑定失败:${t.message}")
            false
        }
    }

    fun stop() {
        running = false
        runCatching { sock?.close() }
        sock = null
        thread = null
        WorldState.setSource("空闲")
    }

    private fun loop(s: DatagramSocket) {
        val buf = ByteArray(64 * 1024)
        while (running) {
            val p = DatagramPacket(buf, buf.size)
            try {
                s.receive(p)
            } catch (e: SocketTimeoutException) {
                continue
            } catch (t: Throwable) {
                break
            }
            val line = String(p.data, p.offset, p.length, Charsets.UTF_8).trim()
            lastPackets++
            lastFrom = "${p.address.hostAddress}:${p.port}"
            if (line.isEmpty()) continue
            if (line == "ping" || line.startsWith("{")) {
                if (line.startsWith("{")) {
                    if (!WorldState.ingestJson(line, "PC:$lastFrom")) {
                        WorldState.setSource("UDP 帧解析失败")
                    }
                } else {
                    WorldState.setSource("PC:$lastFrom")
                }
            }
        }
    }

    /** 调试用：本机回环自喂一帧，验证叠加层是否在动 */
    fun demoFrame() {
        val now = System.currentTimeMillis() / 1000.0
        val sb = StringBuilder()
        sb.append("{\"self\":{\"x\":0,\"z\":0,\"yaw\":0},\"ent\":[")
        for (i in 0 until 6) {
            if (i > 0) sb.append(',')
            val ang = now * 0.6 + i * 1.05
            val r = 18.0 + i * 12.0
            val kind = when (i % 3) {
                0 -> "enemy"
                1 -> "team"
                else -> "sound"
            }
            sb.append("{\"id\":").append(100 + i)
                .append(",\"x\":").append(String.format("%.2f", Math.cos(ang) * r))
                .append(",\"z\":").append(String.format("%.2f", Math.sin(ang) * r))
                .append(",\"kind\":\"").append(kind).append("\"}")
        }
        sb.append("]}")
        WorldState.ingestJson(sb.toString(), "DEMO")
    }
}
