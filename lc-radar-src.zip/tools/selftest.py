"""链路自测：起 UDP 监听 → 跑 pc_radar.py --demo → 校验收到的帧符合手机端协议。"""
import json
import socket
import subprocess
import sys
import time

PORT = 27901
sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind(("127.0.0.1", PORT))
sock.settimeout(6)

here = "/storage/emulated/0/DeltaRadar/tools"
proc = subprocess.Popen(
    [sys.executable, f"{here}/pc_radar.py", "--phone", "127.0.0.1", "--port", str(PORT),
     "--demo", "--fps", "10"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

frames = []
try:
    while len(frames) < 4:
        data, _ = sock.recvfrom(65535)
        f = json.loads(data.decode())
        assert "self" in f and "ent" in f, f
        for e in f["ent"]:
            assert set(e) >= {"id", "x", "z", "kind"}, e
            assert e["kind"] in {"enemy", "team", "sound", "vehicle", "loot", "unknown"}, e
        frames.append(f)
finally:
    proc.terminate()
    out = proc.stdout.read() if proc.stdout else ""
    sock.close()

print("frames ok:", len(frames))
print("sample:", json.dumps(frames[-1], ensure_ascii=False)[:160])
print("--- tool stdout ---")
print(out.strip()[:400])
