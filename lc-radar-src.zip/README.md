# DeltaRadar · 三角洲免 root 雷达

主机工程在 `android/`（Kotlin，可直接 `assembleDebug` 出 APK），PC 视觉源在 `tools/pc_radar.py`。

- 说明与用法：`android/README.md`
- 历史遗留的 Python 骨架在 `src/`（功能已被 `android/` 覆盖，保留备查）
- 打成一个包带走：`lc-radar-src.zip`
