package com.lc.radar.net

import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.atomic.AtomicLong

/** 一条流（五元组去掉方向） */
data class FlowKey(
    val proto: Int,
    val src: String,
    val sport: Int,
    val dst: String,
    val dport: Int
) {
    val protoName: String
        get() = when (proto) {
            6 -> "TCP"
            17 -> "UDP"
            1 -> "ICMP"
            else -> "IP$proto"
        }

    val short: String
        get() = "$protoName $src:$sport → $dst:$dport"
}

class FlowAgg {
    @Volatile var packets: Long = 0
    @Volatile var bytes: Long = 0
    @Volatile var first: Long = 0
    @Volatile var last: Long = 0
    @Volatile var sni: String? = null
    @Volatile var app: String? = null
    @Volatile var uid: Int = -1
    /** 前 96 字节的 hex，贴近真实抓包工具的"包内容"视图 */
    @Volatile var head: String = ""
}

data class Pkt(
    val t: Long,
    val key: FlowKey,
    val len: Int,
    val hex: String,
    val tag: String?
)

/**
 * 抓包结果的进程内存储。UI 直接轮询 topFlows() / packetList()。
 */
object NetLog {
    val flows = ConcurrentHashMap<FlowKey, FlowAgg>()
    private val pkts = ArrayDeque<Pkt>()
    private val lock = Any()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    val totalPackets = AtomicLong()
    val totalBytes = AtomicLong()

    @Volatile var startedAt: Long = 0
    @Volatile var note: String = ""

    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners += l
    }

    fun removeListener(l: () -> Unit) {
        listeners -= l
    }

    fun reset() {
        flows.clear()
        synchronized(lock) { pkts.clear() }
        totalPackets.set(0)
        totalBytes.set(0)
        startedAt = System.currentTimeMillis()
    }

    fun record(
        key: FlowKey,
        len: Int,
        payload: ByteArray?,
        off: Int,
        plen: Int,
        tag: String?,
        app: String?,
        uid: Int,
        sample: Boolean
    ) {
        val agg = flows.getOrPut(key) {
            FlowAgg().also { it.first = System.currentTimeMillis() }
        }
        agg.packets++
        agg.bytes += len.toLong()
        agg.last = System.currentTimeMillis()
        if (tag != null && agg.sni == null) agg.sni = tag
        if (app != null) {
            agg.app = app
            agg.uid = uid
        }
        totalPackets.incrementAndGet()
        totalBytes.addAndGet(len.toLong())

        if (sample && payload != null && plen > 0) {
            val n = minOf(plen, 96)
            val sb = StringBuilder(n * 3)
            for (i in 0 until n) {
                val v = payload[off + i].toInt() and 0xFF
                sb.append(HEX[v ushr 4]).append(HEX[v and 0x0F]).append(' ')
            }
            val hex = sb.toString().trim()
            if (agg.head.isEmpty()) agg.head = hex
            synchronized(lock) {
                pkts.addLast(Pkt(System.currentTimeMillis(), key, plen, hex, tag))
                while (pkts.size > 600) pkts.removeFirst()
            }
        }
    }

    fun packetList(): List<Pkt> = synchronized(lock) { pkts.toList() }

    fun topFlows(): List<Pair<FlowKey, FlowAgg>> =
        flows.entries.map { it.key to it.value }
            .sortedWith(compareByDescending<Pair<FlowKey, FlowAgg>> { it.second.bytes }
                .thenBy { it.first.toString() })

    /** 每个应用各占多少流量，用来看"游戏到底连了哪些域名" */
    fun byApp(): List<Pair<String, Long>> {
        val m = HashMap<String, Long>()
        for ((_, v) in flows) {
            val k = v.app ?: "uid:${v.uid}"
            m[k] = (m[k] ?: 0L) + v.bytes
        }
        return m.entries.map { it.key to it.value }.sortedByDescending { it.second }
    }

    private val HEX = "0123456789abcdef".toCharArray()
}
