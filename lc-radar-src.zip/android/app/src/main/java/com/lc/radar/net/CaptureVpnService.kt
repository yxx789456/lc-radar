package com.lc.radar.net

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import com.lc.radar.Cfg
import com.lc.radar.MainActivity
import java.io.FileDescriptor
import java.io.FileInputStream
import java.io.IOException
import java.net.InetAddress
import java.net.InetSocketAddress

/**
 * 无 root 抓包：靠 VpnService 把目标应用的流量接进用户态（tun），逐包解析展示。
 *
 * 重要设计取舍：
 *  - 只把「目标游戏」放进 VPN（addAllowedApplication），其它 App 完全不受影响；
 *  - 本服务是**观察模式**，不转发数据 —— 抓包期间目标游戏联网会中断。
 *    真要做"边玩边抓"，必须在用户态实现 TCP 栈或做 SOCKS5 中继，那是另一个工程量
 *    （VPN 层能被内核接受的最小实现见 RelayNote）；
 *  - 游戏业务层多半是 QUIC/TLS，载荷是密文，能拿到的是：五元组、包长、节奏、
 *    TLS SNI、HTTP Host、UDP 打点特征。位置数据要靠 [ProtoProbe] 的解密槽位。
 */
class CaptureVpnService : VpnService() {

    companion object {
        const val ACTION_START = "com.lc.radar.action.START_CAP"
        const val ACTION_STOP = "com.lc.radar.action.STOP_CAP"
        private const val CH = "lc_cap"
        private const val NID = 0x2101

        @Volatile
        var alive = false
            private set

        fun start(ctx: android.content.Context) {
            val i = Intent(ctx, CaptureVpnService::class.java).setAction(ACTION_START)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: android.content.Context) {
            // 后台上下文直接 startService 可能被系统拒，包一层
            runCatching {
                ctx.startService(Intent(ctx, CaptureVpnService::class.java).setAction(ACTION_STOP))
            }
        }
    }

    private var tun: ParcelFileDescriptor? = null
    private var worker: Thread? = null
    @Volatile private var running = false

    private val uidCache = HashMap<FlowKey, Int>()

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                shutdown()
                return START_NOT_STICKY
            }
            else -> boot()
        }
        return START_STICKY
    }

    override fun onRevoke() {
        shutdown()
        super.onRevoke()
    }

    override fun onDestroy() {
        shutdown()
        super.onDestroy()
    }

    // ── 启动 ───────────────────────────────────────────────────
    private fun boot() {
        if (alive) return
        startForeground(NID, notification("抓包运行中（目标应用会断网）"))

        val b = Builder()
            .setSession("LC-Radar-Sniff")
            .setMtu(1500)
            .addAddress("10.66.7.1", 32)
            .addRoute("0.0.0.0", 0)
            .addDnsServer("1.1.1.1")
            .setBlocking(true)

        val pkg = Cfg.gamePkg
        if (pkg.isBlank()) {
            NetLog.note = "未设置游戏包名，已取消（避免把全机流量吞掉）"
            stopSelf()
            return
        }
        try {
            b.addAllowedApplication(pkg)
        } catch (e: PackageManager.NameNotFoundException) {
            // 找不到包名时绝不能退化成"放行全部"，否则整台手机会断网
            NetLog.note = "设备里没有 $pkg，已取消抓包"
            stopSelf()
            return
        }

        tun = try {
            b.establish()
        } catch (t: Throwable) {
            null
        }
        if (tun == null) {
            NetLog.note = "VPN 建立失败：另一个 VPN 在运行或未授权"
            stopSelf()
            return
        }

        NetLog.reset()
        NetLog.note = "观察模式 · 目标=$pkg"

        running = true
        alive = true
        val fd = tun!!.fileDescriptor
        worker = Thread({ loop(fd) }, "lc-sniff").also {
            it.isDaemon = true
            it.start()
        }
    }

    private fun shutdown() {
        running = false
        alive = false
        runCatching { worker?.interrupt() }
        worker = null
        runCatching { tun?.close() }
        tun = null
        runCatching { stopForeground(true) }
        runCatching { stopSelf() }
    }

    // ── 读 tun ────────────────────────────────────────────────
    private fun loop(fd: FileDescriptor) {
        val input = FileInputStream(fd)
        val buf = ByteArray(65535)
        while (running) {
            val n = try {
                input.read(buf)
            } catch (e: IOException) {
                break
            } catch (e: Exception) {
                break
            }
            if (n <= 0) continue
            try {
                dispatch(buf, n)
            } catch (t: Throwable) {
                // 单包解析失败绝不影响抓包主循环
            }
        }
    }

    private fun dispatch(b: ByteArray, n: Int) {
        when ((b[0].toInt() and 0xF0) shr 4) {
            4 -> parseV4(b, n)
            6 -> parseV6(b, n)
        }
    }

    private fun parseV4(b: ByteArray, n: Int) {
        val ihl = (b[0].toInt() and 0x0F) * 4
        if (ihl < 20 || n < ihl) return
        val proto = b[9].toInt() and 0xFF
        val total = if (n >= 4) u16(b, 2) else n
        val src = ipv4(b, 12)
        val dst = ipv4(b, 16)

        when (proto) {
            17 -> {
                if (n < ihl + 8) return
                val sp = u16(b, ihl)
                val dp = u16(b, ihl + 2)
                val ulen = u16(b, ihl + 4)
                val off = ihl + 8
                val plen = maxOf(0, minOf(ulen - 8, n - off))
                record(FlowKey(17, src, sp, dst, dp), b, off, plen, total, null)
            }
            6 -> {
                if (n < ihl + 20) return
                val sp = u16(b, ihl)
                val dp = u16(b, ihl + 2)
                val doff = ((b[ihl + 12].toInt() ushr 4) and 0x0F) * 4
                val off = ihl + doff
                if (off > n) return
                val plen = maxOf(0, total - off)
                record(FlowKey(6, src, sp, dst, dp), b, off, plen, total, null)
            }
            else -> Unit
        }
    }

    private fun parseV6(b: ByteArray, n: Int) {
        if (n < 40) return
        val next = b[6].toInt() and 0xFF
        val src = ipv6(b, 8)
        val dst = ipv6(b, 24)
        val plen = u16(b, 4)
        if (next != 6 && next != 17) return
        if (n < 48) return
        val sp = u16(b, 40)
        val dp = u16(b, 42)
        val off = if (next == 17) 48 else {
            if (n < 52) return
            40 + ((b[52].toInt() ushr 4) and 0x0F) * 4
        }
        if (off > n) return
        val body = maxOf(0, minOf(plen, n - 40) - (off - 40))
        record(FlowKey(next, src, sp, dst, dp), b, off, body, n, null)
    }

    private fun record(key: FlowKey, b: ByteArray, off: Int, plen: Int, total: Int, hint: String?) {
        var tag = hint
        if (tag == null && plen > 5) {
            tag = when {
                key.proto == 6 && (key.dport == 443 || key.sport == 443) -> tlsSni(b, off, plen)
                key.proto == 6 && (key.dport == 80 || key.sport == 80) -> httpHost(b, off, plen)
                key.proto == 17 && (key.dport == 443 || key.sport == 443) -> "QUIC(加密)"
                else -> null
            }
        }

        val uid = uidCache.getOrPut(key) { resolveUid(key) }
        val app = if (uid >= 0) uidName(uid) else null

        NetLog.record(
            key = key,
            len = total,
            payload = b,
            off = off,
            plen = plen,
            tag = tag,
            app = app,
            uid = uid,
            sample = plen > 0
        )
    }

    private fun resolveUid(key: FlowKey): Int {
        if (Build.VERSION.SDK_INT < 29) return -1
        return try {
            val cm = getSystemService(ConnectivityManager::class.java)
            val a = InetAddress.getByName(key.src)
            val b = InetAddress.getByName(key.dst)
            cm.getConnectionOwnerUid(
                key.proto,
                InetSocketAddress(a, key.sport),
                InetSocketAddress(b, key.dport)
            )
        } catch (t: Throwable) {
            -1
        }
    }

    private fun uidName(uid: Int): String? = try {
        packageManager.getNameForUid(uid)
    } catch (t: Throwable) {
        null
    }

    // ── 协议嗅探 ───────────────────────────────────────────────
    /** 从 TLS ClientHello 里取出 SNI（明文，QUIC 里取不到） */
    private fun tlsSni(b: ByteArray, off: Int, len: Int): String? {
        if (len < 48) return null
        if (b[off].toInt() != 0x16) return null          // handshake
        if (b[off + 5].toInt() != 0x01) return null      // client_hello
        var p = off + 9                                   // record(5) + hs_type(1) + hs_len(3)
        p += 2 + 32                                       // version + random
        if (p >= off + len) return null
        val sidLen = b[p].toInt() and 0xFF
        p += 1 + sidLen
        val csLen = u16(b, p)
        p += 2 + csLen
        val cmLen = b[p].toInt() and 0xFF
        p += 1 + cmLen
        if (p + 2 > off + len) return null
        val extLen = u16(b, p)
        p += 2
        val end = minOf(p + extLen, off + len)
        while (p + 4 <= end) {
            val type = u16(b, p)
            val elen = u16(b, p + 2)
            p += 4
            if (type == 0 && p + 2 <= end) {
                var q = p + 2
                while (q + 3 <= p + elen && q + 3 <= end) {
                    val nt = b[q].toInt() and 0xFF
                    val nl = u16(b, q + 1)
                    q += 3
                    if (nt == 0 && q + nl <= end) {
                        return String(b, q, nl, Charsets.US_ASCII)
                    }
                    q += nl
                }
            }
            p += elen
        }
        return null
    }

    private fun httpHost(b: ByteArray, off: Int, len: Int): String? {
        val n = minOf(len, 512)
        val s = String(b, off, n, Charsets.ISO_8859_1)
        val idx = s.indexOf("Host:", ignoreCase = true)
        if (idx < 0) return null
        val end = s.indexOf("\r\n", idx)
        if (end < 0) return null
        return s.substring(idx + 5, end).trim()
    }

    // ── 工具 ──────────────────────────────────────────────────
    private fun u16(b: ByteArray, o: Int): Int {
        if (o < 0 || o + 1 >= b.size) return 0
        return ((b[o].toInt() and 0xFF) shl 8) or (b[o + 1].toInt() and 0xFF)
    }

    private fun ipv4(b: ByteArray, o: Int): String {
        if (o + 3 >= b.size) return "0.0.0.0"
        return "${b[o].toInt() and 0xFF}.${b[o + 1].toInt() and 0xFF}." +
            "${b[o + 2].toInt() and 0xFF}.${b[o + 3].toInt() and 0xFF}"
    }

    private fun ipv6(b: ByteArray, o: Int): String = try {
        InetAddress.getByAddress(b.copyOfRange(o, o + 16)).hostAddress ?: "::"
    } catch (t: Throwable) {
        "::"
    }

    // ── 通知 ──────────────────────────────────────────────────
    private fun notification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "抓包", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.stat_sys_download_done)
            .setContentTitle("LC Radar · 抓包")
            .setContentText(text)
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }
}
