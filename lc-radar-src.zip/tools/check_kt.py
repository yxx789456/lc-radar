import glob, re

bad = 0
files = sorted(glob.glob('/storage/emulated/0/DeltaRadar/android/app/src/main/java/**/*.kt', recursive=True))
for f in files:
    s = open(f, encoding='utf-8').read()
    s = re.sub(r'//[^\n]*', '', s)
    s = re.sub(r'/\*.*?\*/', '', s, flags=re.S)
    s = re.sub(r'"(?:\\.|[^"\\])*"', '""', s)
    s = re.sub(r"'(?:\\.|[^'\\])*'", "''", s)
    for op, cl in [('{', '}'), ('(', ')'), ('[', ']')]:
        if s.count(op) != s.count(cl):
            print(f'{f.split("/")[-1]}: {op}{cl} mismatch {s.count(op)}/{s.count(cl)}')
            bad += 1
print('files:', len(files), 'bad:', bad)
