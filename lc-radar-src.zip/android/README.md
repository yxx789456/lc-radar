# LC Radar · 三角洲免 root 雷达（安卓）

一个真能在手机上跑的无 root 雷达 + 抓包显示工具。Kotlin 原生工程，零第三方依赖（只用系统 API），
`assembleDebug` 直接出 APK。

> 这套东西的定位：**HUD 叠加 + 数据源可插拔 + VPN 抓包观察**。
> 无 root 拿不到游戏内存，所以"实体坐标"必须从下面三条路里来，工程已经把它们都接好了，
> 你只要挑一条喂数据，雷达就会画点。

---

## 1. 它到底由什么组成

| 模块 | 文件 | 作用 |
|---|---|---|
| 雷达盘 | `ui/RadarView.kt` | Canvas 绘制，玩家居中、朝向向上，红=敌人 绿=队友 黄=物资 蓝=声源 |
| 悬浮 HUD | `ui/RadarOverlayService.kt` | `TYPE_APPLICATION_OVERLAY` 悬浮窗，默认点击穿透，锁图标可拖动，尺寸可切 |
| 抓包 | `net/CaptureVpnService.kt` | 无 root 抓包：VpnService 把目标游戏流量接进用户态，逐包解析 |
| 抓包显示 | `capture/CaptureActivity.kt` | 流列表（按流量排序）/ 应用归属 / 单包 hex / 协议盲扫 |
| 数据源 1 | `net/UdpFeed.kt` | UDP 收 JSON 帧（PC 视觉、第二台设备、任何外部程序） |
| 数据源 2 | `vision/ScreenCapService.kt` | MediaProjection 屏幕采样 → 颜色检测 → 相对坐标 |
| 数据源 3 | `net/ProtoProbe.kt` | 业务协议解析槽位（解密 → 按 opcode 解坐标 / 盲扫 float 三元组） |
| 内存态 | `core/WorldState.kt` | 所有源往这里写，View 每帧读，带 TTL 淘汰 |
| 关联 | `core/Tracker.kt` | 最近邻 + 低通，视觉散点不乱跳 |
| 控制台 | `MainActivity.kt` | 权限、开关、量程、包名/端口、实时状态 |
| PC 端 | `../tools/pc_radar.py` | adb 抓屏 → 颜色/YOLO → UDP 推给手机 |

三条源可以同时开，`WorldState` 会混合显示；雷达左下角写着当前源。

---

## 2. 编译

需要 JDK 17 + Android SDK 34。两种方式：

**A. Android Studio**：`File → Open` 选 `android/` 目录，直接 Run。

**B. 命令行**
```bash
cd android
gradle wrapper --gradle-version 8.7     # 只需一次
./gradlew assembleDebug
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

手机上装完，第一步永远是给权限：**设置 → 应用 → LC Radar → 显示在其他应用上层**（悬浮窗）。

---

## 3. 四种用法（按可靠性排序）

### ① PC 视觉源（推荐，最稳）
```bash
# 手机和 PC 同一 WiFi；手机开 UDP 调试（USB 调试打开）
pip install numpy opencv-python
python tools/pc_radar.py --phone 192.168.1.23 --port 27888 --fps 6 --preview
```
手机上：`LC Radar → UDP接收 → 悬浮雷达`。
PC 上先不加 `--preview` 跑一遍，看控制台 `ent=6` 就说明链路通了（`--demo` 可以完全脱离游戏验证）。

> HUD 默认是**点击穿透**（不抢游戏触摸），所以它自己的按钮点不到。
> 要拖动位置：先在 `LC Radar` 里点「锁定/拖动」解锁 → 拖完再点一次锁回去。

### ② 手机内视觉源（不用 PC）
`LC Radar → 视觉源`（弹一次屏幕捕获授权）`→ 悬浮雷达`。
这条链路是纯颜色检测（红名牌=敌人、青名牌=队友），精度看场景，
想准就把 `vision/ColorDetector.kt` 换成一个 YOLO 实现（接口只有 `detect(bmp): List<Box>`）。

### ③ 抓包显示（分析用，不能边玩边抓）
`LC Radar → 抓包`（弹一次 VPN 授权）`→ 抓包界面`。
能看：五元组、每流包数/字节、应用归属（`getConnectionOwnerUid`）、
TLS **SNI**、HTTP **Host**、QUIC 标记、首包 hex、长按看最近 12 包。
> 观察模式不转发，所以**抓包期间目标游戏会断网**，其它 App 不受影响（只把游戏放进 VPN）。
> 这是刻意的：真做"边玩边抓"要在用户态实现 TCP 栈或 SOCKS 中继，工程量翻几倍。

### ④ 协议解析（真正能出坐标的那条）
`net/ProtoProbe.kt` 里三个 TODO 槽位：
```kotlin
OPCODES   // opcode → xOff/zOff/stride/countOff
sessionKey// 会话级密钥
deobfuscate()  // 解密实现
```
拿到了明文包，用抓包界面里的「盲扫首个流」先看有没有 float 三元组，
人肉比 2~3 帧定 stride，再把偏移写进 `OPCODES`，`decodeKnown()` 就会吐实体。

---

## 4. 数据协议（UDP，一帧一包）

```json
{"self":{"x":0,"z":0,"yaw":0},
 "ent":[{"id":11,"x":12.4,"z":-3.1,"kind":"enemy","hp":80,"label":"vis"}]}
```
- `x/z` 单位米，`z` 向前为正；`yaw` 度，0=面向 +z，顺时针为正。
- `kind`：`enemy` `team` `loot` `sound` `vehicle` `unknown`。
- `{"clear":true}` 清空当前目标。
- 单包 `ping` 也算心跳。

手机端 5 秒没收到新帧，点会自动消失（`WorldState` TTL），不会留一堆鬼影。

---

## 5. 标定（视觉源精度全靠这三个数）

| 参数 | 位置 | 意义 |
|---|---|---|
| `fovDeg` | Cfg | 水平视场角，默认 90；换镜头/改画质要重标 |
| `horizon` | Cfg | 地平线在屏幕高度中的位置，默认 0.42 |
| `distK` | Cfg | `dist = distK / (cy - horizon)`；拿一个已知距离目标反解 |

标定法：站定，让一个明确 20m 的目标落在 `cy=0.60`，则 `distK = 20 × (0.60-0.42) = 3.6`。
写进 `MainActivity` 的 Cfg 或直接改 `Cfg.distK` 默认值。

---

## 6. 现实边界（照着做之前先知道）

1. **无 root 读不到内存**。`/proc/<pid>/mem` 在现代 Android 上要 root/内核权限，
   所有"内存雷达"本质上都得先有 root 或 Magisk 模块。所以本工程不给内存路径。
2. **业务包基本是密文**。手游同步走 QUIC/TLS，抓包拿到的是密文；
   能从中确认的只有端点、节奏、包长分布。要坐标必须解决会话密钥 —— `ProtoProbe` 留了槽位，没替你假装成功。
3. **服务端只下发你视野内的实体**（可见性裁剪）。即使解密成功也画不出"全图"，
   这是服务端权威设计的硬约束。
4. **悬浮窗可能被系统/游戏隐藏**：部分游戏调 `Window#setHideOverlayWindows(true)`，
   或有 `FLAG_SECURE` 窗口，HUD 会直接不显示。这条在客户端无法绕过，退路是第二块屏/外部显示设备。
5. **反作弊会看进程与浮层**。ACE 一类的检测会枚举 overlay、异常包名、无障碍、
   VPN 与截屏会话。想长期用，别把 HUD 常驻在登录/结算阶段，也别在同一个进程里堆可疑特征。
   （这部分属于对抗工程，本工程只提供功能，不内置任何隐藏手段。）
6. **发热和掉帧**：手机内视觉源 + 游戏同跑会掉帧，长局建议走 PC 视觉源。

---

## 7. 故障排查

| 现象 | 原因/处理 |
|---|---|
| HUD 不出现 | 没给「显示在其他应用上层」；或目标游戏隐藏了 overlay |
| HUD 出现但没点 | 数据源没数据；点「演示」看雷达是否转，转=链路 OK |
| 抓包界面空的 | VPN 授权被拒；或另一个 VPN 在跑（系统只允许一个） |
| VPN 起来后游戏掉线 | 正常，观察模式不转发；分析完点「停 抓包」 |
| UDP 绑不上 | 端口被占（换 27889）；多网卡时在 `Cfg.udpBind` 指定 IP |
| PC 推了没反应 | 手机和 PC 不同网段；或安卓侧防火墙/热点隔离；先 `--demo` 排查 |

---

## 8. 目录

```
DeltaRadar/
├── android/                 # 本工程（Kotlin）
│   ├── app/src/main/java/com/lc/radar/
│   │   ├── MainActivity.kt  App.kt  Cfg.kt
│   │   ├── core/            WorldState  Tracker
│   │   ├── net/             CaptureVpnService  NetLog  UdpFeed  ProtoProbe
│   │   ├── ui/              RadarView  RadarOverlayService
│   │   ├── capture/         CaptureActivity
│   │   └── vision/          ColorDetector  ScreenCapService
│   └── app/src/main/AndroidManifest.xml
├── tools/pc_radar.py        # PC 视觉源
└── src/ ...                 # 早前的 Python 骨架（历史留存，功能已被 android/ 覆盖）
```
