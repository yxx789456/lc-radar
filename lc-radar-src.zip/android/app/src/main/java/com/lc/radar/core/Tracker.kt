package com.lc.radar.core

import kotlin.math.hypot

/**
 * 极简多目标跟踪：视觉检测每帧给出散点，这里做最近邻关联 + 平滑，
 * 让雷达上的点不会一帧一帧乱跳。id 段从 1000000 起，避让 UDP 数据源的 id。
 */
class Tracker(private val gate: Float = 6f, private val ttlMs: Long = 1200L) {

    private class Item(
        val id: Long,
        var x: Float,
        var z: Float,
        val kind: WorldState.Kind,
        var t: Long
    )

    private val items = ArrayList<Item>(32)
    private var nextId = 1_000_000L

    /** pts: (x, z, kind) */
    fun update(pts: List<Triple<Float, Float, WorldState.Kind>>) {
        val now = System.currentTimeMillis()
        val used = BooleanArray(items.size)

        for ((x, z, kind) in pts) {
            var best = -1
            var bestD = Float.MAX_VALUE
            for (i in items.indices) {
                if (used[i]) continue
                val it = items[i]
                if (it.kind != kind) continue
                val d = hypot(it.x - x, it.z - z)
                if (d < bestD && d < gate) {
                    bestD = d
                    best = i
                }
            }
            if (best >= 0) {
                used[best] = true
                val it = items[best]
                // 一阶低通，α = 0.5
                it.x += (x - it.x) * 0.5f
                it.z += (z - it.z) * 0.5f
                it.t = now
            } else {
                items += Item(nextId++, x, z, kind, now)
            }
        }

        items.removeIf { now - it.t > ttlMs }

        val out = ArrayList<WorldState.Ent>(items.size)
        for (it in items) {
            if (now - it.t > ttlMs / 2) continue
            out += WorldState.Ent(it.id, it.x, it.z, it.kind, label = "vis")
        }
        if (out.isNotEmpty()) WorldState.upsertAll(out)
    }

    fun reset() {
        items.clear()
    }
}
