package com.lc.radar.vision

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** 归一化检测框（0~1，相对截图） */
data class Box(
    val cx: Float,
    val cy: Float,
    val w: Float,
    val h: Float,
    val score: Float,
    val cls: Int
) {
    companion object {
        const val ENEMY = 0
        const val TEAM = 1
    }
}

/**
 * 轻量颜色检测：不依赖任何模型，先把"视觉源"这条链路跑通。
 *
 * 判据（手游里最稳的两种视觉特征）：
 *  - 敌人：红色系名牌/描边（r 显著高于 g、b）
 *  - 队友：青绿/蓝色系名牌（g、b 高而 r 低）
 * 连通域用 flood-fill，输出外接框；宽高比像名牌的块才算，滤掉大片场景元素。
 *
 * 想换 YOLO：只要提供一个 `fun detect(bmp: Bitmap): List<Box>` 的类，
 * 在 ScreenCapService 里替换 detector 即可，坐标协议不变。
 */
class ColorDetector(private val sampleW: Int = 200) {

    fun detect(src: Bitmap): List<Box> {
        if (src.width < 8 || src.height < 8) return emptyList()
        val sw = sampleW
        val sh = max(8, (src.height.toFloat() * sw / src.width).toInt())
        val small = Bitmap.createScaledBitmap(src, sw, sh, true)
        val pix = IntArray(sw * sh)
        small.getPixels(pix, 0, sw, 0, 0, sw, sh)
        if (small !== src) small.recycle()

        val enemyMask = BooleanArray(sw * sh)
        val teamMask = BooleanArray(sw * sh)
        for (i in pix.indices) {
            val c = pix[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            if (r > 115 && r - g > 50 && r - b > 45) {
                enemyMask[i] = true
            } else if (g > 120 && b > 110 && g - r > 40) {
                teamMask[i] = true
            }
        }

        val out = ArrayList<Box>(16)
        collect(enemyMask, sw, sh, Box.ENEMY, out)
        collect(teamMask, sw, sh, Box.TEAM, out)
        return out
    }

    private fun collect(mask: BooleanArray, w: Int, h: Int, cls: Int, out: MutableList<Box>) {
        val seen = BooleanArray(mask.size)
        val stack = IntArray(mask.size)
        for (start in mask.indices) {
            if (!mask[start] || seen[start]) continue

            var sp = 0
            stack[sp++] = start
            seen[start] = true
            var minX = w
            var maxX = -1
            var minY = h
            var maxY = -1
            var count = 0

            while (sp > 0) {
                val idx = stack[--sp]
                val x = idx % w
                val y = idx / w
                count++
                if (x < minX) minX = x
                if (x > maxX) maxX = x
                if (y < minY) minY = y
                if (y > maxY) maxY = y

                if (x > 0) {
                    val n = idx - 1
                    if (mask[n] && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
                if (x < w - 1) {
                    val n = idx + 1
                    if (mask[n] && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
                if (y > 0) {
                    val n = idx - w
                    if (mask[n] && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
                if (y < h - 1) {
                    val n = idx + w
                    if (mask[n] && !seen[n]) { seen[n] = true; stack[sp++] = n }
                }
            }

            if (count < 6) continue
            val bw = maxX - minX + 1
            val bh = maxY - minY + 1
            if (bw < 4 || bh < 2) continue
            if (bw > w * 0.45f) continue
            val aspect = bw.toFloat() / bh
            if (aspect < 0.7f || aspect > 9f) continue

            out += Box(
                cx = ((minX + maxX) / 2f) / w,
                cy = ((minY + maxY) / 2f) / h,
                w = bw.toFloat() / w,
                h = bh.toFloat() / h,
                score = min(1f, count / 40f),
                cls = cls
            )
        }
    }
}
