package com.lc.radar.core

import org.json.JSONObject
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList

/**
 * 全局世界状态：所有数据源（UDP / 视觉 / 抓包解析 / 演示）都往这里写，
 * 雷达 View 每帧从这里读。
 *
 * 坐标系：右手系，x 向右，z 向前（y 是高度，雷达用不到）。
 * yawDeg：玩家朝向，0 = 面向 +z（正前方），顺时针为正（俯视）。
 */
object WorldState {

    enum class Kind { ENEMY, TEAM, SELF, LOOT, SOUND, VEHICLE, UNKNOWN }

    data class Pose(val x: Float = 0f, val z: Float = 0f, val yawDeg: Float = 0f)

    data class Ent(
        val id: Long,
        val x: Float,
        val z: Float,
        val kind: Kind,
        val hp: Int = -1,
        val label: String = "",
        val t: Long = System.currentTimeMillis()
    )

    @Volatile
    var pose: Pose = Pose()
        private set

    @Volatile
    var lastFeedAt: Long = 0L
        private set

    @Volatile
    var source: String = "空闲"
        private set

    @Volatile
    var feedCount: Long = 0L
        private set

    private val ents = ConcurrentHashMap<Long, Ent>()
    private val listeners = CopyOnWriteArrayList<() -> Unit>()

    // ── 监听 ───────────────────────────────────────────────────
    fun addListener(l: () -> Unit) {
        if (!listeners.contains(l)) listeners += l
    }

    fun removeListener(l: () -> Unit) {
        listeners -= l
    }

    private fun fire() {
        for (l in listeners) runCatching { l() }
    }

    fun setSource(s: String) {
        source = s
        fire()
    }

    // ── 写入 ───────────────────────────────────────────────────
    fun setPose(x: Float, z: Float, yawDeg: Float) {
        pose = Pose(x, z, yawDeg)
        lastFeedAt = System.currentTimeMillis()
        feedCount++
    }

    fun upsert(e: Ent) {
        ents[e.id] = e
        lastFeedAt = System.currentTimeMillis()
        feedCount++
        fire()
    }

    fun upsertAll(list: List<Ent>) {
        for (e in list) ents[e.id] = e
        lastFeedAt = System.currentTimeMillis()
        feedCount += list.size
        fire()
    }

    fun remove(id: Long) {
        ents.remove(id)
        fire()
    }

    fun clear() {
        ents.clear()
        lastFeedAt = 0
        fire()
    }

    /** 取快照，顺手淘汰过期目标（默认 3s 不刷新就认为丢了） */
    fun snapshot(ttlMs: Long = 3000): List<Ent> {
        val now = System.currentTimeMillis()
        ents.entries.removeIf { now - it.value.t > ttlMs }
        return ents.values.toList()
    }

    // ── 协议解析：一行 JSON ────────────────────────────────────
    // {"self":{"x":12.5,"z":-3.0,"yaw":37.5},
    //  "ent":[{"id":7,"x":20,"z":-9,"kind":"enemy","hp":80,"label":"vis"}]}
    fun ingestJson(line: String, src: String): Boolean {
        return try {
            val o = JSONObject(line)
            o.optJSONObject("self")?.let {
                setPose(
                    it.optDouble("x", 0.0).toFloat(),
                    it.optDouble("z", 0.0).toFloat(),
                    it.optDouble("yaw", 0.0).toFloat()
                )
            }
            o.optJSONArray("ent")?.let { arr ->
                val batch = ArrayList<Ent>(arr.length())
                for (i in 0 until arr.length()) {
                    val e = arr.optJSONObject(i) ?: continue
                    val kind = parseKind(e.optString("kind", ""))
                    batch += Ent(
                        id = e.optLong("id", (src.hashCode().toLong() and 0xFFFF) * 100000 + i),
                        x = e.optDouble("x", 0.0).toFloat(),
                        z = e.optDouble("z", 0.0).toFloat(),
                        kind = kind,
                        hp = e.optInt("hp", -1),
                        label = e.optString("label", "")
                    )
                }
                if (batch.isNotEmpty()) upsertAll(batch)
            }
            if (o.has("clear") && o.optBoolean("clear")) clear()
            source = src
            true
        } catch (t: Throwable) {
            false
        }
    }

    private fun parseKind(s: String): Kind = when (s.lowercase().trim()) {
        "enemy", "e", "enemies", "red" -> Kind.ENEMY
        "team", "teammate", "t", "friend", "green" -> Kind.TEAM
        "self", "me", "local" -> Kind.SELF
        "loot", "item", "supply", "box" -> Kind.LOOT
        "sound", "noise", "footstep", "shot" -> Kind.SOUND
        "vehicle", "car" -> Kind.VEHICLE
        else -> Kind.UNKNOWN
    }
}
