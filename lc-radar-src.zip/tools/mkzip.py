"""把可直接编译的工程打成一个 zip，方便从手机拷到 PC。"""
import os
import zipfile

ROOT = "/storage/emulated/0/Download/DeltaRadar"
OUT = os.path.join(ROOT, "lc-radar-src.zip")

INCLUDE = ["android", "tools", "README.md", ".gitignore", ".github"]
SKIP_DIRS = {"build", ".gradle", ".idea", "__pycache__", ".git"}
SKIP_EXT = {".pyc"}

n = 0
with zipfile.ZipFile(OUT, "w", zipfile.ZIP_DEFLATED) as z:
    for item in INCLUDE:
        p = os.path.join(ROOT, item)
        if os.path.isfile(p):
            z.write(p, item)
            n += 1
            continue
        for base, dirs, files in os.walk(p):
            dirs[:] = [d for d in dirs if d not in SKIP_DIRS]
            for f in files:
                if os.path.splitext(f)[1] in SKIP_EXT:
                    continue
                full = os.path.join(base, f)
                rel = os.path.relpath(full, ROOT)
                z.write(full, rel)
                n += 1

print("wrote", OUT, "files:", n, "size:", os.path.getsize(OUT))
