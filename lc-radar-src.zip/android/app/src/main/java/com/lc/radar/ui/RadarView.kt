package com.lc.radar.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Typeface
import android.view.View
import com.lc.radar.Cfg
import com.lc.radar.core.WorldState
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * 雷达盘。玩家永远在圆心，向上 = 当前朝向；目标按相对坐标投点。
 * 纯 Canvas 绘制，60fps 下开销可忽略。
 */
class RadarView(ctx: Context) : View(ctx) {

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xCC060B10.toInt()
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = 0x552FD6A0
    }
    private val cross = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1f
        color = 0x332FD6A0
    }
    private val sweep = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        color = 0xAA2FD6A0.toInt()
    }

    /** 拖尾画笔预建好，onDraw 里不 new 对象 */
    private val trail: Array<Paint> = Array(9) { k ->
        Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 2f
            color = 0xFF2FD6A0.toInt()
            alpha = (130 - k * 13).coerceAtLeast(12)
        }
    }

    private val blip = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val selfP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.FILL
        color = 0xFF5CD6FF.toInt()
    }
    private val soundRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.4f
        color = 0x664DD2FF
    }
    private val vehicleRing = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = 0x66FF9A3D
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFB9F6D8.toInt()
        textSize = 22f
        typeface = Typeface.MONOSPACE
    }
    private val txtDim = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x99B9F6D8.toInt()
        textSize = 18f
        typeface = Typeface.MONOSPACE
    }

    private val triangle = Path()
    private var t0 = System.currentTimeMillis()

    /** 由外部（服务）驱动，避免 View 自己开定时器 */
    fun frame() {
        if (isShown) postInvalidateDelayed(33)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val cx = w / 2f
        val cy = h / 2f
        val radius = min(w, h) / 2f - 16f

        canvas.drawCircle(cx, cy, radius, bg)

        for (i in 1..4) canvas.drawCircle(cx, cy, radius * i / 4f, ring)
        canvas.drawLine(cx - radius, cy, cx + radius, cy, cross)
        canvas.drawLine(cx, cy - radius, cx, cy + radius, cross)

        // 扫描线 + 拖尾
        val period = 2400f
        val base = ((System.currentTimeMillis() - t0) % period.toLong()).toFloat() / period * 360f
        val a0 = Math.toRadians(base.toDouble())
        canvas.drawLine(
            cx, cy,
            cx + (radius * sin(a0)).toFloat(),
            cy - (radius * cos(a0)).toFloat(),
            sweep
        )
        for (k in trail.indices) {
            val a = Math.toRadians((base - (k + 1) * 2.2f).toDouble())
            canvas.drawLine(
                cx, cy,
                cx + (radius * sin(a)).toFloat(),
                cy - (radius * cos(a)).toFloat(),
                trail[k]
            )
        }

        // 目标
        val pose = WorldState.pose
        val rot = Math.toRadians(-pose.yawDeg.toDouble())
        val ca = cos(rot).toFloat()
        val sa = sin(rot).toFloat()
        val range = Cfg.rangeM.coerceAtLeast(10f)
        val ttl = if (WorldState.source.startsWith("UDP")) 4000L else 1500L
        val list = WorldState.snapshot(ttl)

        for (e in list) {
            val dx = e.x - pose.x
            val dz = e.z - pose.z
            val rx = dx * ca - dz * sa
            val rz = dx * sa + dz * ca
            val px = cx + rx / range * radius
            val py = cy + rz / range * radius
            if (hypot(px - cx, py - cy) > radius) continue

            blip.color = colorOf(e.kind)
            when (e.kind) {
                WorldState.Kind.SOUND -> {
                    canvas.drawCircle(px, py, 3.5f, blip)
                    canvas.drawCircle(px, py, 15f, soundRing)
                }
                WorldState.Kind.VEHICLE -> {
                    canvas.drawCircle(px, py, 7f, blip)
                    canvas.drawCircle(px, py, 11f, vehicleRing)
                }
                else -> canvas.drawCircle(px, py, 6f, blip)
            }

            if (Cfg.showDistance) {
                val meters = hypot(dx, dz)
                if (meters >= 1f) canvas.drawText("${meters.toInt()}m", px + 8f, py - 7f, txtDim)
            }
        }

        // 玩家
        triangle.reset()
        triangle.moveTo(cx, cy - 11f)
        triangle.lineTo(cx - 8f, cy + 9f)
        triangle.lineTo(cx + 8f, cy + 9f)
        triangle.close()
        canvas.drawPath(triangle, selfP)

        canvas.drawText("N", cx - 7f, 24f, txtDim)
        canvas.drawText("E", w - 24f, cy + 6f, txtDim)

        canvas.drawText("${Cfg.rangeM.toInt()}m", 8f, h - 10f, txt)
        canvas.drawText(WorldState.source.take(22), 74f, h - 10f, txtDim)
        val n = list.count { it.kind == WorldState.Kind.ENEMY }
        canvas.drawText("E:$n", w - 58f, h - 10f, txtDim)

        frame()
    }

    private fun colorOf(k: WorldState.Kind): Int = when (k) {
        WorldState.Kind.ENEMY -> 0xFFFF4D4D.toInt()
        WorldState.Kind.TEAM -> 0xFF4DFF88.toInt()
        WorldState.Kind.LOOT -> 0xFFFFD24D.toInt()
        WorldState.Kind.SOUND -> 0xFF4DD2FF.toInt()
        WorldState.Kind.VEHICLE -> 0xFFFF9A3D.toInt()
        WorldState.Kind.SELF -> 0xFF5CD6FF.toInt()
        else -> 0xFFB0B0B0.toInt()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        t0 = System.currentTimeMillis()
        frame()
    }
}
