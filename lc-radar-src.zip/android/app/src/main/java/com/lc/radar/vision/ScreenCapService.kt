package com.lc.radar.vision

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import com.lc.radar.Cfg
import com.lc.radar.MainActivity
import com.lc.radar.core.Tracker
import com.lc.radar.core.WorldState
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

/**
 * 数据源 2：屏幕视觉。
 *
 * 无 root 也能拿到屏幕内容（MediaProjection 一次授权；FLAG_SECURE 的窗口抓不到，
 * 一般 3D 场景不在保护范围）。链路：
 *   VirtualDisplay → ImageReader(RGBA_8888) → 复用 Bitmap → ColorDetector
 *   → 归一化框 → (方位角, 距离) → Tracker → WorldState → 雷达
 *
 * 精度：单目单帧只能给方位 + 粗距离，靠 Cfg.fovDeg / Cfg.horizon / Cfg.distK 标定；
 * 想准就换 YOLO（接口只有 detect(bmp): List<Box>），或者走 tools/pc_radar.py。
 */
class ScreenCapService : Service() {

    companion object {
        private const val CH = "lc_vision"
        private const val NID = 0x2103

        @Volatile
        var alive = false
            private set

        private var code = 0
        private var data: Intent? = null

        fun start(ctx: Context, resultCode: Int, resultData: Intent) {
            code = resultCode
            data = resultData
            val i = Intent(ctx, ScreenCapService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ScreenCapService::class.java))
        }
    }

    private var proj: MediaProjection? = null
    private var vd: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null

    private var lastTs = 0L
    private var frames = 0L

    private val detector = ColorDetector()
    private val tracker = Tracker(gate = 8f, ttlMs = 1400L)

    /** ImageReader 给的是 RGBA 字节序，直接塞进 ARGB_8888 位图会红蓝互换，这里换回来 */
    private val swapPaint = Paint().apply {
        isFilterBitmap = true
        colorFilter = ColorMatrixColorFilter(
            ColorMatrix(
                floatArrayOf(
                    0f, 0f, 1f, 0f, 0f,
                    0f, 1f, 0f, 0f, 0f,
                    1f, 0f, 0f, 0f, 0f,
                    0f, 0f, 0f, 1f, 0f
                )
            )
        )
    }
    private var frameBuf: Bitmap? = null
    private var rawBuf: Bitmap? = null

    override fun onCreate() {
        super.onCreate()
        startForeground(NID, notification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        boot()
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        teardown()
        super.onDestroy()
    }

    private fun boot() {
        if (alive) return
        val d = data ?: return
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = try {
            mgr.getMediaProjection(code, d)
        } catch (t: Throwable) {
            null
        }
        if (proj == null) {
            WorldState.setSource("视觉:授权失效")
            stopSelf()
            return
        }

        val t = HandlerThread("lc-vision").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h

        // Android 14+ 要求 createVirtualDisplay 之前先注册回调，否则直接抛
        proj!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                teardown()
                stopSelf()
            }
        }, h)

        val dm = resources.displayMetrics
        val w = 720
        val hgt = max(480, (dm.heightPixels.toFloat() * w / dm.widthPixels).toInt())

        reader = ImageReader.newInstance(w, hgt, PixelFormat.RGBA_8888, 3)
        vd = proj!!.createVirtualDisplay(
            "lc-vision",
            w, hgt, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, h
        )
        reader!!.setOnImageAvailableListener({ r -> onFrame(r) }, h)

        alive = true
        WorldState.setSource("视觉 ${w}x$hgt")
    }

    private fun teardown() {
        alive = false
        runCatching { reader?.setOnImageAvailableListener(null, null) }
        runCatching { reader?.close() }
        reader = null
        runCatching { vd?.release() }
        vd = null
        runCatching { proj?.stop() }
        proj = null
        runCatching { thread?.quitSafely() }
        thread = null
        handler = null
        runCatching { frameBuf?.recycle() }
        frameBuf = null
        runCatching { rawBuf?.recycle() }
        rawBuf = null
        tracker.reset()
        runCatching { stopForeground(true) }
    }

    // ── 每帧 ──────────────────────────────────────────────────
    private fun onFrame(r: ImageReader) {
        val img = try {
            r.acquireLatestImage()
        } catch (t: Throwable) {
            null
        } ?: return

        try {
            val now = System.currentTimeMillis()
            val interval = (1000L / Cfg.visionFps.coerceIn(2, 30)).coerceAtLeast(33L)
            if (now - lastTs < interval) return
            lastTs = now

            val plane = img.planes[0]
            val ps = plane.pixelStride
            val rs = plane.rowStride
            val iw = img.width
            val ih = img.height
            val pad = rs - ps * iw
            val bw = if (pad > 0) iw + pad / ps else iw

            val raw = rawBuf?.takeIf { it.width == bw && it.height == ih }
                ?: Bitmap.createBitmap(bw, ih, Bitmap.Config.ARGB_8888).also {
                    rawBuf?.recycle()
                    rawBuf = it
                }
            raw.copyPixelsFromBuffer(plane.buffer)

            val frame = frameBuf?.takeIf { it.width == iw && it.height == ih }
                ?: Bitmap.createBitmap(iw, ih, Bitmap.Config.ARGB_8888).also {
                    frameBuf?.recycle()
                    frameBuf = it
                }

            // 抠掉右侧 padding + 红蓝通道换回
            Canvas(frame).drawBitmap(raw, Rect(0, 0, iw, ih), Rect(0, 0, iw, ih), swapPaint)

            val boxes = detector.detect(frame)
            pushBoxes(boxes)
            frames++
        } catch (t: Throwable) {
            // 单帧失败无所谓
        } finally {
            runCatching { img.close() }
        }
    }

    /**
     * 归一化框 → 世界坐标：
     *   方位 = (cx*2-1) * FOV/2
     *   距离 = distK / max(0.02, cy - horizon)
     * 这是"画面位置 → 雷达相对点"的基本几何近似，比例尺靠标定。
     */
    private fun pushBoxes(boxes: List<Box>) {
        if (boxes.isEmpty()) return
        // 视觉源没有真实位姿：玩家当原点，朝向当正前方
        WorldState.setPose(0f, 0f, 0f)

        val fov = Cfg.fovDeg.coerceIn(50f, 130f)
        val horizon = Cfg.horizon.coerceIn(0.1f, 0.9f)
        val k = Cfg.distK.coerceAtLeast(0.5f)

        val pts = ArrayList<Triple<Float, Float, WorldState.Kind>>(boxes.size)
        for (b in boxes) {
            if (b.score < 0.15f) continue
            val bearingDeg = (b.cx * 2f - 1f) * fov / 2f
            val raw = b.cy - horizon
            val denom = if (raw < 0.02f) 0.02f else raw
            val dist = (k / denom).coerceIn(1.5f, 280f)
            if (dist < 3f) continue          // 太近的多半是自己的 HUD
            val rad = Math.toRadians(bearingDeg.toDouble())
            val x = (sin(rad) * dist).toFloat()
            val z = (cos(rad) * dist).toFloat()
            val kind = if (b.cls == Box.TEAM) WorldState.Kind.TEAM else WorldState.Kind.ENEMY
            pts += Triple(x, z, kind)
        }
        tracker.update(pts)
        WorldState.setSource("视觉 ${boxes.size}框")
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "视觉源", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("LC Radar · 视觉源")
            .setContentText("屏幕采样 + 颜色检测")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }
}
