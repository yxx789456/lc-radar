#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pc_radar.py —— 三角洲免 root 雷达 · PC 侧视觉源

思路：手机不需要 root，也不需要装什么驱动。
      用 adb 从 USB/WiFi 抓手机屏幕 → PC 上跑检测（颜色 或 YOLO）→
      把"相对坐标"用 UDP 一帧一帧推给手机上的 LC Radar（HUD 立刻画点）。

为什么放 PC：手机端同时跑游戏 + 视觉检测会掉帧发热；PC 侧可以上 YOLO，
             还能顺手录屏/回放/调参。

依赖：
    pip install numpy opencv-python
    # 可选，想用 YOLO：
    pip install ultralytics

用法：
    # 1) 手机开 USB 调试，adb devices 能看到设备
    # 2) 手机 LC Radar 里点「UDP接收」，记下手机 WiFi IP
    python pc_radar.py --phone 192.168.1.23 --port 27888

    # 用 YOLO 模型
    python pc_radar.py --phone 192.168.1.23 --model weights/delta.pt --conf 0.4

    # 没有手机/没有游戏，先验证链路通不通
    python pc_radar.py --phone 192.168.1.23 --demo

协议（UDP 一帧一包，UTF-8 JSON）：
    {"self":{"x":0,"z":0,"yaw":0},
     "ent":[{"id":11,"x":12.4,"z":-3.1,"kind":"enemy"}]}
    kind: enemy / team / loot / sound / vehicle
"""

import argparse
import json
import math
import socket
import subprocess
import sys
import time

try:
    import numpy as np
except ImportError:
    np = None  # --demo 不需要 numpy；真抓屏时再检查

ADB = "adb"


# ─────────────────────────────────────────────────────────────
# 屏幕采集
# ─────────────────────────────────────────────────────────────
def grab_png(serial, timeout=4.0):
    cmd = [ADB]
    if serial:
        cmd += ["-s", serial]
    cmd += ["exec-out", "screencap", "-p"]
    try:
        r = subprocess.run(cmd, capture_output=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        return None
    if r.returncode != 0 or not r.stdout:
        return None
    return r.stdout


def decode(png):
    if np is None:
        sys.exit("需要 numpy: pip install numpy")
    try:
        import cv2
    except ImportError:
        sys.exit("需要 opencv: pip install opencv-python")
    arr = np.frombuffer(png, dtype=np.uint8)
    return cv2.imdecode(arr, cv2.IMREAD_COLOR)


# ─────────────────────────────────────────────────────────────
# 检测：颜色兜底 / YOLO
# ─────────────────────────────────────────────────────────────
def detect_color(img, sample_w: int = 240):
    """和手机端 ColorDetector 同一套判据：红=敌人，青绿=队友。返回归一化框。"""
    import cv2
    h, w = img.shape[:2]
    scale = sample_w / float(w)
    small = cv2.resize(img, (sample_w, max(8, int(h * scale))))
    b, g, r = small[:, :, 0].astype(np.int16), small[:, :, 1].astype(np.int16), small[:, :, 2].astype(np.int16)

    enemy = ((r > 115) & (r - g > 50) & (r - b > 45)).astype(np.uint8)
    team = ((g > 120) & (b > 110) & (g - r > 40)).astype(np.uint8)

    boxes = []
    for mask, cls in ((enemy, 0), (team, 1)):
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((3, 3), np.uint8))
        n, _, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
        sh, sw = mask.shape[:2]
        for i in range(1, n):
            x, y, bw, bh, area = stats[i]
            if area < 12 or bw < 4 or bh < 2:
                continue
            if bw > sw * 0.45:
                continue
            aspect = bw / float(bh)
            if aspect < 0.7 or aspect > 9.0:
                continue
            boxes.append({
                "cx": (x + bw / 2.0) / sw,
                "cy": (y + bh / 2.0) / sh,
                "w": bw / float(sw),
                "h": bh / float(sh),
                "score": min(1.0, area / 60.0),
                "cls": cls,
            })
    return boxes


_YOLO = None


def detect_yolo(img, model_path: str, conf: float):
    global _YOLO
    if _YOLO is None:
        try:
            from ultralytics import YOLO
        except ImportError:
            sys.exit("需要 ultralytics: pip install ultralytics")
        _YOLO = YOLO(model_path)
    res = _YOLO.predict(img, conf=conf, verbose=False)[0]
    h, w = img.shape[:2]
    out = []
    names = res.names
    for b in res.boxes:
        x1, y1, x2, y2 = [float(v) for v in b.xyxy[0].tolist()]
        name = str(names.get(int(b.cls), ""))
        cls = 1 if ("team" in name or "friend" in name or "mate" in name) else 0
        out.append({
            "cx": (x1 + x2) / 2.0 / w,
            "cy": (y1 + y2) / 2.0 / h,
            "w": (x2 - x1) / w,
            "h": (y2 - y1) / h,
            "score": float(b.conf),
            "cls": cls,
        })
    return out


# ─────────────────────────────────────────────────────────────
# 几何：屏幕归一化框 → 雷达相对坐标（和手机端 ScreenCapService 一致）
# ─────────────────────────────────────────────────────────────
def to_world(boxes, fov_deg: float, horizon: float, distk: float):
    pts = []
    for b in boxes:
        if b["score"] < 0.15:
            continue
        bearing = (b["cx"] * 2 - 1) * fov_deg / 2.0
        denom = max(0.02, b["cy"] - horizon)
        dist = min(280.0, max(1.5, distk / denom))
        if dist < 3.0:
            continue  # 太近的多半是自己 HUD
        rad = math.radians(bearing)
        pts.append({
            "x": round(math.sin(rad) * dist, 2),
            "z": round(math.cos(rad) * dist, 2),
            "kind": "team" if b["cls"] == 1 else "enemy",
        })
    return pts


def demo_frame(t: float):
    ents = []
    for i in range(6):
        ang = t * 0.7 + i * 1.05
        r = 18 + i * 13
        ents.append({
            "id": 500 + i,
            "x": round(math.cos(ang) * r, 2),
            "z": round(math.sin(ang) * r, 2),
            "kind": ("enemy", "team", "sound")[i % 3],
        })
    return ents


def main():
    ap = argparse.ArgumentParser(description="三角洲免 root 雷达 · PC 视觉源")
    ap.add_argument("--phone", required=True, help="手机上 LC Radar 所在设备的 IP")
    ap.add_argument("--port", type=int, default=27888, help="手机 UDP 监听端口")
    ap.add_argument("--serial", default=None, help="adb 设备序列号（多设备时指定）")
    ap.add_argument("--fps", type=float, default=6.0)
    ap.add_argument("--fov", type=float, default=90.0, help="水平视场角")
    ap.add_argument("--horizon", type=float, default=0.42, help="地平线归一化 y")
    ap.add_argument("--distk", type=float, default=8.0, help="距离系数 dist=distk/(cy-horizon)")
    ap.add_argument("--model", default=None, help="YOLO 权重路径（不填走颜色检测）")
    ap.add_argument("--conf", type=float, default=0.35)
    ap.add_argument("--demo", action="store_true", help="不发真图，只推演示帧验证链路")
    ap.add_argument("--preview", action="store_true", help="本地弹出预览窗口（需要 GUI）")
    args = ap.parse_args()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    addr = (args.phone, args.port)
    interval = 1.0 / max(0.5, args.fps)
    print(f"[*] 目标 {addr[0]}:{addr[1]}  fps={args.fps}  "
          f"{'YOLO ' + args.model if args.model else '颜色检测'}")

    t0 = time.time()
    n = 0
    while True:
        loop_start = time.time()
        t = time.time() - t0

        if args.demo:
            ents = demo_frame(t)
        else:
            png = grab_png(args.serial)
            if png is None:
                print("[!] 抓屏失败：确认 adb devices 里有设备、且手机没锁屏")
                time.sleep(1.0)
                continue
            img = decode(png)
            if img is None:
                time.sleep(0.2)
                continue
            boxes = (detect_yolo(img, args.model, args.conf) if args.model
                     else detect_color(img))
            ents = to_world(boxes, args.fov, args.horizon, args.distk)
            if args.preview:
                try:
                    import cv2
                    for b in boxes:
                        h, w = img.shape[:2]
                        x1 = int((b["cx"] - b["w"] / 2) * w)
                        y1 = int((b["cy"] - b["h"] / 2) * h)
                        x2 = int((b["cx"] + b["w"] / 2) * w)
                        y2 = int((b["cy"] + b["h"] / 2) * h)
                        color = (0, 0, 255) if b["cls"] == 0 else (0, 255, 0)
                        cv2.rectangle(img, (x1, y1), (x2, y2), color, 2)
                    cv2.imshow("lc-radar", img)
                    if cv2.waitKey(1) == 27:
                        break
                except Exception as e:
                    print("[!] 预览失败:", e)

        frame = {"self": {"x": 0, "z": 0, "yaw": 0}, "ent": ents}
        payload = json.dumps(frame, separators=(",", ":")).encode("utf-8")
        try:
            sock.sendto(payload, addr)
        except OSError as e:
            print("[!] 发送失败:", e)

        n += 1
        if n % 20 == 0:
            print(f"[{n:5d}] ent={len(ents)}  {payload[:90]!r}")

        time.sleep(max(0.0, interval - (time.time() - loop_start)))

    sock.close()


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[bye]")
