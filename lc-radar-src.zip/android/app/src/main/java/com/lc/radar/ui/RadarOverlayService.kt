package com.lc.radar.ui

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.lc.radar.Cfg
import com.lc.radar.MainActivity
import com.lc.radar.core.WorldState
import com.lc.radar.net.UdpFeed

/**
 * 悬浮雷达 HUD。
 * 关键点：
 *  - TYPE_APPLICATION_OVERLAY，不需要 root，只需用户手动授予"显示在其他应用上层"；
 *  - 默认 FLAG_NOT_TOUCHABLE（点击穿透），不抢游戏触摸；点 HUD 上的锁图标可解锁拖动；
 *  - 部分游戏会调 Window#setHideOverlayWindows(true) / 安全窗口，这类情况下 HUD 会被系统隐藏
 *    （这是系统级行为，改不了），退路是第二块屏 / 外部设备显示。
 */
class RadarOverlayService : Service() {

    companion object {
        private const val CH = "lc_hud"
        private const val NID = 0x2102

        @Volatile
        var alive = false
            private set

        @Volatile
        var inst: RadarOverlayService? = null
            private set

        fun start(ctx: Context) {
            val i = Intent(ctx, RadarOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, RadarOverlayService::class.java))
        }
    }

    private lateinit var wm: WindowManager
    private var root: LinearLayout? = null
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var radar: RadarView
    private lateinit var title: TextView
    private lateinit var lockBtn: TextView
    private val ui = Handler(Looper.getMainLooper())

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        startForeground(NID, notification())
        inst = this
        alive = true
        build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        alive = false
        inst = null
        runCatching { root?.let { wm.removeView(it) } }
        root = null
        runCatching { stopForeground(true) }
        super.onDestroy()
    }

    // ── 构建 HUD ──────────────────────────────────────────────
    private fun build() {
        val dp = resources.displayMetrics.density
        fun d(v: Int) = (v * dp).toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(6), d(4), d(6), d(6))
            background = GradientDrawable().apply {
                cornerRadius = d(14).toFloat()
                setColor(0x40000000)
                setStroke(d(1), 0x552FD6A0)
            }
        }

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }

        title = TextView(this).apply {
            text = "◉ LC RADAR"
            setTextColor(0xFF2FD6A0.toInt())
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setPadding(d(4), 0, d(8), 0)
        }
        bar.addView(title, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))

        lockBtn = TextView(this).apply {
            text = if (Cfg.locked) "🔒" else "✥"
            textSize = 13f
            setPadding(d(6), 0, d(6), 0)
            setOnClickListener {
                Cfg.locked = !Cfg.locked
                applyLock()
            }
        }
        bar.addView(lockBtn)

        val close = TextView(this).apply {
            text = "✕"
            setTextColor(0xFFFF6B6B.toInt())
            textSize = 13f
            setPadding(d(6), 0, d(4), 0)
            setOnClickListener { stopSelf() }
        }
        bar.addView(close)

        box.addView(bar, LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)

        radar = RadarView(this)
        val size = d(Cfg.hudSizeDp.coerceIn(180, 520))
        box.addView(radar, LinearLayout.LayoutParams(size, size))

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = d(18)
            y = d(180)
        }
        if (Build.VERSION.SDK_INT >= 30) {
            // 别让悬浮窗被状态栏/挖孔挤走
            runCatching { params.fitInsetsTypes = 0 }
        }
        runCatching { title.setTextColor(Color.parseColor("#2FD6A0")) }

        root = box
        runCatching { wm.addView(box, params) }

        applyLock()

        // 头栏拖动
        bar.setOnTouchListener { _, ev -> drag(ev) }

        // 数据源没跑的时候给个提示，避免看到空盘以为坏了
        ui.postDelayed({
            if (WorldState.lastFeedAt == 0L && UdpFeed.lastPackets == 0L) {
                title.text = "◉ 无数据源"
            }
        }, 2500)
    }

    private var dx = 0f
    private var dy = 0f
    private var downX = 0
    private var downY = 0

    private fun drag(ev: MotionEvent): Boolean {
        if (Cfg.locked) return false
        when (ev.action) {
            MotionEvent.ACTION_DOWN -> {
                downX = params.x
                downY = params.y
                dx = ev.rawX
                dy = ev.rawY
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                params.x = downX + (ev.rawX - dx).toInt()
                params.y = downY + (ev.rawY - dy).toInt()
                runCatching { root?.let { wm.updateViewLayout(it, params) } }
                return true
            }
            MotionEvent.ACTION_UP -> return true
        }
        return false
    }

    private fun applyLock() {
        val r = root ?: return
        var f = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        if (Cfg.locked) f = f or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        params.flags = f
        runCatching { wm.updateViewLayout(r, params) }
        lockBtn.text = if (Cfg.locked) "🔒" else "✥"
        title.text = if (Cfg.locked) "◉ LC RADAR · 穿透" else "◉ LC RADAR · 拖动"
    }

    /** 外部改尺寸后重建 */
    fun rebuild() {
        runCatching { root?.let { wm.removeView(it) } }
        root = null
        build()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (nm.getNotificationChannel(CH) == null) {
            nm.createNotificationChannel(
                NotificationChannel(CH, "悬浮雷达", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle("LC Radar 悬浮层")
            .setContentText("雷达 HUD 运行中")
            .setOngoing(true)
            .setContentIntent(pi)
            .build()
    }
}
