package com.lc.radar.net

import com.lc.radar.core.WorldState
import kotlin.math.abs
import kotlin.math.hypot

/**
 * 游戏业务协议探针 —— 这是整套东西里唯一"看得见实体坐标"的入口，
 * 也是必须由你落地的地方（不同版本/不同模式的包结构会变）。
 *
 * 两条路：
 *  A. 已知协议：把 [OPCODES] 填上 opcode → 字段偏移，走 decodeKnown()；
 *  B. 未知协议：先解决"解密/去混淆"（[deobfuscate]），再跑 blindScanFloatTriples()
 *     把疑似坐标三元组的位置找出来，人肉比对 2~3 帧确定 stride 和偏移，
 *     最后把 offsets 写死成 A 路。
 *
 * 现实前提（务必先读）：
 *  - 手游同步层基本是 QUIC + 自研字节协议，载荷加密/混淆；抓到的是密文，
 *    必须先拿到会话密钥（登录握手里的 DH/ECDH 派生），否则 B 路根本无从开始。
 *  - 服务端只下发"你自己视野内"的实体，且带可见性裁剪。所以即便解密成功，
 *    也拿不到全图，只能拿到你本来就能看到（或即将看到）的目标 —— 这是服务端
 *    权威设计的硬边界，不是抓包手法问题。
 */
object ProtoProbe {

    /** opcode → 字段布局描述。填上就是 A 路。 */
    data class OpSpec(
        val name: String,
        val xOff: Int,
        val zOff: Int,
        val stride: Int = 12,
        val countOff: Int = -1,
        val kind: WorldState.Kind = WorldState.Kind.ENEMY
    )

    /** TODO(HOOK-1)：把真实 opcode 填进来 */
    val OPCODES: Map<Int, OpSpec> = mapOf(
        // 0x21 to OpSpec("ENTITY_SYNC", xOff = 6, zOff = 10, stride = 12, countOff = 2),
    )

    /** TODO(HOOK-2)：业务层混淆用的 XOR/RC4 密钥槽（会话级，登录后派生） */
    @Volatile
    var sessionKey: ByteArray? = null

    /** TODO(HOOK-3)：解密实现槽位，默认原样返回 */
    fun deobfuscate(payload: ByteArray, len: Int): ByteArray {
        val key = sessionKey ?: return payload.copyOf(len)
        if (key.isEmpty()) return payload.copyOf(len)
        val out = ByteArray(len)
        for (i in 0 until len) {
            out[i] = (payload[i].toInt() xor key[i % key.size].toInt()).toByte()
        }
        return out
    }

    /** A 路：按 [OPCODES] 解析 */
    fun decodeKnown(buf: ByteArray): List<WorldState.Ent> {
        if (buf.size < 2) return emptyList()
        val op = buf[0].toInt() and 0xFF
        val spec = OPCODES[op] ?: return emptyList()
        val count = if (spec.countOff >= 0 && spec.countOff < buf.size) {
            buf[spec.countOff].toInt() and 0xFF
        } else {
            (buf.size - spec.xOff) / spec.stride
        }
        val out = ArrayList<WorldState.Ent>(count)
        var p = spec.xOff
        var i = 0
        while (i < count && p + spec.stride <= buf.size) {
            val x = f32(buf, p)
            val z = f32(buf, p + 4)
            out += WorldState.Ent(
                id = (op.toLong() shl 24) or i.toLong(),
                x = x,
                z = z,
                kind = spec.kind,
                label = spec.name
            )
            p += spec.stride
            i++
        }
        return out
    }

    /**
     * B 路：盲扫 float32 三元组。
     * 用于"我已经把某段包解密出来了，但不知道坐标在哪"的阶段。
     * 判据：有限、量级合理、三元组内部不要出现整数计数那种整齐值。
     */
    fun blindScanFloatTriples(buf: ByteArray, minVec: Float = 0.05f, maxVec: Float = 20000f): List<FloatArray> {
        val res = ArrayList<FloatArray>()
        var i = 0
        while (i + 12 <= buf.size) {
            val a = f32(buf, i)
            val b = f32(buf, i + 4)
            val c = f32(buf, i + 8)
            if (plausible(a, minVec, maxVec) && plausible(b, minVec, maxVec) && plausible(c, minVec, maxVec)) {
                val mag = hypot(a.toDouble(), c.toDouble()).toFloat()
                if (mag in minVec..maxVec) {
                    if (res.none { abs(it[0] - a) < 0.01f && abs(it[2] - c) < 0.01f }) {
                        res += floatArrayOf(a, b, c)
                    }
                }
            }
            i += 4
        }
        return res
    }

    /** 把盲扫结果打成可读报告，方便在抓包界面里直接看 */
    fun scanReport(buf: ByteArray, limit: Int = 12): String {
        val hits = blindScanFloatTriples(buf)
        if (hits.isEmpty()) return "无可疑 float 三元组（多半仍是密文）"
        val sb = StringBuilder("可疑三元组 ${hits.size} 组：\n")
        for ((i, h) in hits.withIndex()) {
            if (i >= limit) break
            sb.append("  #").append(i).append("  x=")
                .append(String.format("%.2f", h[0])).append("  y=")
                .append(String.format("%.2f", h[1])).append("  z=")
                .append(String.format("%.2f", h[2])).append('\n')
        }
        return sb.toString()
    }

    // ── 小工具 ────────────────────────────────────────────────
    private fun f32(b: ByteArray, o: Int): Float {
        if (o + 3 >= b.size) return Float.NaN
        val bits = (b[o].toInt() and 0xFF) or
            ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or
            ((b[o + 3].toInt() and 0xFF) shl 24)
        return Float.fromBits(bits)
    }

    private fun plausible(v: Float, min: Float, max: Float): Boolean =
        v.isFinite() && abs(v) >= min && abs(v) <= max
}
