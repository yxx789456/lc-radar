package com.lc.radar

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Cfg.init(this)
        val def = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            // 崩溃时别把 HUD 留在屏幕上挡手，也不能让未捕获异常再次打断主线程
            runCatching { ui.RadarOverlayService.stop(this) }
            def?.uncaughtException(t, e)
        }
    }
}
