package com.lc.radar

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.lc.radar.capture.CaptureActivity
import com.lc.radar.core.WorldState
import com.lc.radar.net.CaptureVpnService
import com.lc.radar.net.NetLog
import com.lc.radar.net.UdpFeed
import com.lc.radar.ui.RadarOverlayService
import com.lc.radar.ui.RadarView
import com.lc.radar.vision.ScreenCapService

/**
 * 控制台：所有开关都在这里，雷达本体在预览区和悬浮窗。
 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var log: TextView
    private lateinit var preview: RadarView
    private lateinit var hudBtn: Button
    private lateinit var capBtn: Button
    private lateinit var visBtn: Button
    private lateinit var udpBtn: Button
    private lateinit var demoBtn: Button
    private lateinit var pkgEt: EditText
    private lateinit var portEt: EditText

    private val ui = Handler(Looper.getMainLooper())
    private var demoOn = false

    private val demo = object : Runnable {
        override fun run() {
            UdpFeed.demoFrame()
            ui.postDelayed(this, 120)
        }
    }

    private val refresh = object : Runnable {
        override fun run() {
            render()
            ui.postDelayed(this, 500)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val dp = resources.displayMetrics.density
        fun d(v: Int) = (v * dp).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(d(14), d(18), d(14), d(14))
        }

        root.addView(TextView(this).apply {
            text = "LC RADAR · 三角洲免 root 雷达"
            textSize = 17f
            setTextColor(Color.parseColor("#2FD6A0"))
            typeface = Typeface.MONOSPACE
        })

        status = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 11.5f
            setTextColor(Color.parseColor("#B9F6D8"))
            setPadding(0, d(6), 0, d(6))
        }
        root.addView(status)

        // 预览雷达（不开悬浮窗也能看到数据）
        preview = RadarView(this)
        root.addView(preview, LinearLayout.LayoutParams(d(230), d(230)))

        // 行 1：HUD
        val r1 = row()
        hudBtn = mkBtn("悬浮雷达") { toggleHud() }
        r1.addView(hudBtn)
        r1.addView(mkBtn("锁定/拖动") {
            Cfg.locked = !Cfg.locked
            RadarOverlayService.inst?.rebuild()
        })
        r1.addView(mkBtn("尺寸") { cycleSize() })
        root.addView(r1)

        // 行 2：抓包
        val r2 = row()
        capBtn = mkBtn("抓包") { toggleCapture() }
        r2.addView(capBtn)
        r2.addView(mkBtn("抓包界面") { startActivity(Intent(this, CaptureActivity::class.java)) })
        r2.addView(mkBtn("清空") { NetLog.reset() })
        root.addView(r2)

        // 行 3：视觉 / UDP
        val r3 = row()
        visBtn = mkBtn("视觉源") { toggleVision() }
        r3.addView(visBtn)
        udpBtn = mkBtn("UDP接收") { toggleUdp() }
        r3.addView(udpBtn)
        demoBtn = mkBtn("演示") { toggleDemo() }
        r3.addView(demoBtn)
        root.addView(r3)

        // 行 4：量程
        val r4 = row()
        for (m in intArrayOf(50, 100, 200, 300)) {
            r4.addView(mkBtn("${m}m") {
                Cfg.rangeM = m.toFloat()
            })
        }
        root.addView(r4)

        // 行 5：参数
        val r5 = row()
        pkgEt = EditText(this).apply {
            setText(Cfg.gamePkg)
            textSize = 11f
            hint = "游戏包名"
            setSingleLine()
        }
        r5.addView(pkgEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 2f))
        portEt = EditText(this).apply {
            setText(Cfg.udpPort.toString())
            textSize = 11f
            hint = "UDP端口"
            setSingleLine()
        }
        r5.addView(portEt, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r5.addView(mkBtn("保存") { saveCfg() })
        root.addView(r5)

        // 日志
        log = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 10.5f
            setTextColor(Color.parseColor("#7FBFAA"))
            setText("提示：抓包=观察模式，会让目标游戏断网；正常游戏请关掉抓包，只用 HUD + 数据源。")
        }
        val sv = ScrollView(this).apply { addView(log) }
        root.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        setContentView(root)
        askNotification()
    }

    override fun onResume() {
        super.onResume()
        ui.post(refresh)
    }

    override fun onPause() {
        super.onPause()
        ui.removeCallbacks(refresh)
    }

    override fun onDestroy() {
        ui.removeCallbacks(refresh)
        ui.removeCallbacks(demo)
        super.onDestroy()
    }

    // ── UI 辅助 ───────────────────────────────────────────────
    private fun row() = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
    }

    private fun mkBtn(text0: String, onClick: () -> Unit): Button = Button(this).apply {
        text = text0
        textSize = 11.5f
        isAllCaps = false
        setPadding(0, 0, 0, 0)
        layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        setOnClickListener { onClick() }
    }

    private fun saveCfg() {
        Cfg.gamePkg = pkgEt.text.toString()
        Cfg.udpPort = portEt.text.toString().toIntOrNull() ?: 27888
        toast("已保存：${Cfg.dump()}")
    }

    private fun cycleSize() {
        Cfg.hudSizeDp = when (Cfg.hudSizeDp) {
            300 -> 380
            380 -> 240
            else -> 300
        }
        RadarOverlayService.inst?.rebuild()
    }

    private fun toast(s: String) {
        log.text = s
    }

    // ── 各开关 ────────────────────────────────────────────────
    private fun toggleHud() {
        if (RadarOverlayService.alive) {
            RadarOverlayService.stop(this)
            toast("HUD 已停止")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("先给悬浮窗权限")
            startActivity(
                Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
            )
            return
        }
        RadarOverlayService.start(this)
        toast("HUD 已启动")
    }

    private fun toggleCapture() {
        if (CaptureVpnService.alive) {
            CaptureVpnService.stop(this)
            toast("抓包已停止")
            return
        }
        val prep = VpnService.prepare(this)
        if (prep != null) {
            startActivityForResult(prep, REQ_VPN)
        } else {
            CaptureVpnService.start(this)
            toast("抓包已启动（目标应用会断网）")
        }
    }

    private fun toggleVision() {
        if (ScreenCapService.alive) {
            ScreenCapService.stop(this)
            WorldState.setSource("空闲")
            toast("视觉源已停止")
            return
        }
        val mgr = getSystemService(MediaProjectionManager::class.java)
        startActivityForResult(mgr.createScreenCaptureIntent(), REQ_PROJ)
    }

    private fun toggleUdp() {
        if (UdpFeed.running) {
            UdpFeed.stop()
            toast("UDP 已停止")
        } else {
            val ok = UdpFeed.start(Cfg.udpPort)
            toast(if (ok) "UDP 监听 ${Cfg.udpPort}" else "UDP 端口占用/绑定失败")
        }
    }

    private fun toggleDemo() {
        demoOn = !demoOn
        if (demoOn) {
            ui.post(demo)
            toast("演示数据开（看雷达点是否在转）")
        } else {
            ui.removeCallbacks(demo)
            WorldState.clear()
            toast("演示数据关")
        }
    }

    // ── 权限 ──────────────────────────────────────────────────
    private fun askNotification() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_VPN -> {
                if (resultCode == RESULT_OK) {
                    CaptureVpnService.start(this)
                    toast("抓包已启动（目标应用会断网）")
                } else {
                    toast("VPN 未授权")
                }
            }
            REQ_PROJ -> {
                if (resultCode == RESULT_OK && data != null) {
                    ScreenCapService.start(this, resultCode, data)
                    toast("视觉源已启动")
                } else {
                    toast("屏幕捕获未授权")
                }
            }
        }
    }

    // ── 状态渲染 ──────────────────────────────────────────────
    private fun render() {
        hudBtn.text = if (RadarOverlayService.alive) "停 HUD" else "悬浮雷达"
        capBtn.text = if (CaptureVpnService.alive) "停 抓包" else "抓包"
        visBtn.text = if (ScreenCapService.alive) "停 视觉" else "视觉源"
        udpBtn.text = if (UdpFeed.running) "停 UDP" else "UDP接收"
        demoBtn.text = if (demoOn) "停 演示" else "演示"

        val ents = WorldState.snapshot(4000)
        val age = if (WorldState.lastFeedAt == 0L) -1
        else ((System.currentTimeMillis() - WorldState.lastFeedAt) / 100).toInt()

        status.text = buildString {
            append("HUD ").append(if (RadarOverlayService.alive) "ON" else "off")
            append(" · 抓包 ").append(if (CaptureVpnService.alive) "ON" else "off")
            append(" · 视觉 ").append(if (ScreenCapService.alive) "ON" else "off")
            append(" · UDP ").append(if (UdpFeed.running) Cfg.udpPort.toString() else "off")
            append('\n')
            append("源 ").append(WorldState.source)
            append(" · 目标 ").append(ents.size)
            append(" · 末帧 ").append(if (age < 0) "—" else "${age * 100}ms")
            append('\n')
            append("包 ").append(NetLog.totalPackets.get())
            append(" · 流 ").append(NetLog.flows.size)
            append(" · ").append(Cfg.dump())
        }
    }

    companion object {
        private const val REQ_VPN = 1001
        private const val REQ_PROJ = 1002
        private const val REQ_NOTIF = 1003
    }
}
