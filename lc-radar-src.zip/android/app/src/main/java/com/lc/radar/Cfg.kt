package com.lc.radar

import android.content.Context
import android.content.SharedPreferences

/**
 * 全部可调参数集中在这里。改完立刻生效（读的时候实时取 sp）。
 */
object Cfg {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        sp = c.applicationContext.getSharedPreferences("lc_radar", Context.MODE_PRIVATE)
    }

    private fun put(k: String, v: Any?) {
        if (!::sp.isInitialized) return
        val e = sp.edit()
        when (v) {
            is String -> e.putString(k, v)
            is Int -> e.putInt(k, v)
            is Float -> e.putFloat(k, v)
            is Boolean -> e.putBoolean(k, v)
            else -> e.putString(k, v?.toString())
        }
        e.apply()
    }

    // ── 目标游戏 ────────────────────────────────────────────────
    /** 三角洲行动 国服包名；国际服可用 com.proxima.delta 覆盖 */
    var gamePkg: String
        get() = sp.getString("game_pkg", "com.tencent.tmgp.dfm") ?: "com.tencent.tmgp.dfm"
        set(v) = put("game_pkg", v.trim())

    // ── 雷达 HUD ───────────────────────────────────────────────
    var rangeM: Float
        get() = sp.getFloat("range_m", 100f)
        set(v) = put("range_m", v)

    var hudSizeDp: Int
        get() = sp.getInt("hud_dp", 300)
        set(v) = put("hud_dp", v)

    var showDistance: Boolean
        get() = sp.getBoolean("show_dist", true)
        set(v) = put("show_dist", v)

    /** true = 点击穿透（HUD 不吃触摸，能正常玩游戏） */
    var locked: Boolean
        get() = sp.getBoolean("locked", true)
        set(v) = put("locked", v)

    // ── 数据源 ─────────────────────────────────────────────────
    var udpPort: Int
        get() = sp.getInt("udp_port", 27888)
        set(v) = put("udp_port", v)

    /** 空字符串 = 监听所有网卡 */
    var udpBind: String
        get() = sp.getString("udp_bind", "") ?: ""
        set(v) = put("udp_bind", v)

    // ── 视觉标定（Cam 源）───────────────────────────────────────
    /** 水平视场角，度。三角洲手游默认 90 左右，自己按手感改 */
    var fovDeg: Float
        get() = sp.getFloat("fov", 90f)
        set(v) = put("fov", v)

    /** 地平线在屏幕高度中的归一化位置（0.42 ≈ 略高于屏幕中心） */
    var horizon: Float
        get() = sp.getFloat("horizon", 0.42f)
        set(v) = put("horizon", v)

    /** 距离系数：dist = distK / (cy - horizon)。标定：已知 20m 目标落在 cy=0.6 → distK = 20*0.18 = 3.6 */
    var distK: Float
        get() = sp.getFloat("dist_k", 8f)
        set(v) = put("dist_k", v)

    var visionFps: Int
        get() = sp.getInt("vis_fps", 10)
        set(v) = put("vis_fps", v)

    fun dump(): String = buildString {
        append("game=").append(gamePkg)
        append(" range=").append(rangeM.toInt()).append('m')
        append(" udp=").append(udpPort)
        append(" fov=").append(fovDeg.toInt())
    }
}
